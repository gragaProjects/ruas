    <link href="<?php echo base_url(); ?>assets/css/countries.css" rel="stylesheet" type="text/css" /> 
    <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/countries.js"></script> 

    <script>
          $('#subexample4').DataTable({
            
      });
    </script>